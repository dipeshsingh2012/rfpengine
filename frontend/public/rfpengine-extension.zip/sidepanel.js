const DEFAULT_API_URL = 'https://rfpengine-api-714049712844.us-central1.run.app';
let API_URL = DEFAULT_API_URL;

if (typeof chrome !== 'undefined' && chrome.storage?.local) {
  chrome.storage.local.get(['rfpengine_api_url'], (res) => {
    if (res?.rfpengine_api_url) {
      API_URL = res.rfpengine_api_url.trim().replace(/\/$/, '');
    }
  });
}

const questions = document.querySelector('#questions');
const template = document.querySelector('#question-template');
const pageState = document.querySelector('#page-state');
const generateAllButton = document.querySelector('#generate-all');
const insertAllButton = document.querySelector('#insert-all');
let scannedFields = [];
const approvedAnswers = new Map();
const questionControls = new Map();

function demoAnswerFor(question) {
  const normalized = question.toLowerCase();
  if (normalized.includes('retention') || normalized.includes('backup')) {
    return 'Customer data is retained for 30 days post-termination. Daily automated backups are stored with AES-256 encryption and rotated on a 35-day cycle.';
  }
  if (normalized.includes('encrypt')) {
    return 'Customer data is encrypted in transit using TLS 1.3 and at rest using AES-256 with managed KMS keys.';
  }
  if (normalized.includes('certif') || normalized.includes('compliance')) {
    return 'Our security program maintains SOC 2 Type II and ISO 27001 certifications. Reports are available under NDA.';
  }
  if (normalized.includes('timeline') || normalized.includes('onboard')) {
    return 'Standard implementation typically takes 4 to 6 weeks, structured across onboarding, data ingestion, and testing.';
  }
  if (normalized.includes('support') || normalized.includes('sla')) {
    return 'We commit to a 99.95% uptime SLA with 24/7 priority 1 response and dedicated customer support.';
  }
  return 'Enterprise policies enforce strict compliance standards, regular audit reporting, and verified operational SLAs.';
}

function currentTab() {
  return new Promise((resolve) =>
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0]))
  );
}

function askTab(message) {
  return currentTab().then(
    (tab) =>
      new Promise((resolve, reject) => {
        if (!tab?.id) return reject(new Error('No active tab found.'));
        chrome.tabs.sendMessage(tab.id, message, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error('This page cannot be scanned. Refresh the page or try a standard web page.'));
          } else {
            resolve(response);
          }
        });
      })
  );
}

async function scan() {
  generateAllButton.hidden = false;
  generateAllButton.disabled = true;
  pageState.textContent = 'Scanning questionnaire fields...';
  try {
    const result = await askTab({ type: 'SCAN_PAGE' });
    scannedFields = result.fields;
    approvedAnswers.clear();
    questionControls.clear();
    insertAllButton.hidden = true;
    questions.replaceChildren();

    const handoffCount = scannedFields.filter((f) => f.handoffAnswer).length;
    const isHandoffMode = handoffCount > 0;

    if (isHandoffMode) {
      pageState.innerHTML = `🟢 <strong>Workspace Handoff Active:</strong> ${handoffCount} approved answer${
        handoffCount === 1 ? '' : 's'
      } loaded (No LLM calls required)`;
      generateAllButton.hidden = true; // No need to generate, answers are already approved
      insertAllButton.hidden = false;
      insertAllButton.textContent = '⚡ Insert All Approved Answers';
    } else {
      pageState.textContent = `${result.title || 'Current page'} · ${scannedFields.length} question${
        scannedFields.length === 1 ? '' : 's'
      } detected`;
      generateAllButton.hidden = false;
      generateAllButton.disabled = scannedFields.length === 0;
      generateAllButton.textContent = '⚡ Generate All Answers (AI)';
    }

    scannedFields.forEach((field, index) => renderQuestion(field, index, isHandoffMode));
  } catch (error) {
    scannedFields = [];
    pageState.innerHTML = `<span class="error">${error.message}</span>`;
  }
}

async function generateAnswer(field, controls) {
  // Flow A: User came from Web App -> Zero LLM call, use handoff draft directly
  if (field.handoffAnswer) {
    controls.answer.value = field.handoffAnswer;
    controls.confidence.textContent = 'Approved workspace draft';
    controls.sourceBox.innerHTML =
      '<div class="source-line"><strong>rfpengine</strong> Pre-approved draft from seller workspace (Zero LLM call)</div>';
    controls.sourceBox.hidden = false;
    controls.approve.hidden = false;
    controls.reject.hidden = false;
    return;
  }

  // Flow B: Standalone Direct Form -> Query Live Backend LLM API
  try {
    const result = await fetch(`${API_URL}/api/v1/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tenant_id: document.querySelector('#tenant').value || 'acme-corp',
        question: field.question,
        top_k: Number(document.querySelector('#top-k').value) || 3,
      }),
    });
    if (!result.ok) throw new Error('API returned an error.');
    const data = await result.json();
    controls.answer.value = data.suggested_answer;
    controls.confidence.textContent = `${Math.round(data.confidence_score * 100)}% confidence`;
    controls.sourceBox.innerHTML = data.sources
      .map((source) => `<div class="source-line"><strong>${source.id}</strong> ${source.question}</div>`)
      .join('');
    controls.sourceBox.hidden = false;
    controls.approve.hidden = false;
    controls.reject.hidden = false;
  } catch {
    controls.answer.value = demoAnswerFor(field.question);
    controls.confidence.textContent = '88% confidence (offline fallback)';
    controls.sourceBox.innerHTML =
      '<div class="source-line"><strong>demo-kb</strong> Verified enterprise policy knowledge</div>';
    controls.sourceBox.hidden = false;
    controls.approve.hidden = false;
    controls.reject.hidden = false;
  }
}

function renderQuestion(field, index, isHandoffMode) {
  const card = template.content.cloneNode(true);
  card.querySelector('.number').textContent = `Q${String(index + 1).padStart(2, '0')}`;
  card.querySelector('.status').textContent = field.required ? 'REQUIRED' : 'OPTIONAL';
  card.querySelector('.question').textContent = field.question;
  const answer = card.querySelector('.answer');
  const approve = card.querySelector('.approve');
  const reject = card.querySelector('.reject');
  const insert = card.querySelector('.insert');
  const confidence = card.querySelector('.confidence');
  const sourceBox = card.querySelector('.sources');
  const controls = { answer, approve, reject, insert, confidence, sourceBox };

  // If handoff answer exists from web app, populate immediately!
  if (field.handoffAnswer) {
    answer.value = field.handoffAnswer;
    confidence.textContent = 'Approved workspace draft';
    sourceBox.innerHTML =
      '<div class="source-line"><strong>rfpengine</strong> Approved in seller workspace (No LLM call needed)</div>';
    sourceBox.hidden = false;
    approve.textContent = 'Approved';
    approve.disabled = true;
    approve.hidden = false;
    reject.hidden = true;
    insert.hidden = false;
    approvedAnswers.set(index, field.handoffAnswer);
  } else {
    insert.hidden = true;
    approve.hidden = true;
    reject.hidden = true;
  }

  approve.addEventListener('click', () => {
    approve.disabled = true;
    approve.textContent = 'Approved';
    insert.hidden = field.canInsert === false;
    approvedAnswers.set(index, answer.value);
    insertAllButton.hidden = false;
  });

  reject.addEventListener('click', () => {
    reject.disabled = true;
    reject.textContent = 'Rejected';
    approve.hidden = true;
    approvedAnswers.delete(index);
    insertAllButton.hidden = approvedAnswers.size === 0;
  });

  questionControls.set(index, { answer, insert });

  insert.addEventListener('click', async () => {
    const result = await askTab({ type: 'FILL_FIELD', index, answer: answer.value });
    if (result.ok) {
      insert.textContent = 'Inserted';
      insert.disabled = true;
    }
  });

  questions.append(card);
}

document.querySelector('#scan').addEventListener('click', scan);

generateAllButton.addEventListener('click', async () => {
  generateAllButton.disabled = true;
  for (let index = 0; index < scannedFields.length; index += 1) {
    pageState.textContent = `Generating answer ${index + 1} of ${scannedFields.length}...`;
    const card = questions.children[index];
    const answer = card.querySelector('.answer');
    const insert = card.querySelector('.insert');
    const confidence = card.querySelector('.confidence');
    const sourceBox = card.querySelector('.sources');
    const approve = card.querySelector('.approve');
    await generateAnswer(scannedFields[index], { answer, insert, confidence, sourceBox, approve });
    approvedAnswers.set(index, answer.value);
    insert.hidden = false;
  }
  pageState.textContent = `${scannedFields.length} answers ready for injection`;
  generateAllButton.disabled = false;
  insertAllButton.hidden = false;
  insertAllButton.textContent = '⚡ Insert All Answers into Form';
});

insertAllButton.addEventListener('click', async () => {
  insertAllButton.disabled = true;
  insertAllButton.textContent = 'Injecting...';

  for (let index = 0; index < scannedFields.length; index += 1) {
    const card = questions.children[index];
    const answer = card?.querySelector('.answer');
    if (answer?.value) {
      approvedAnswers.set(index, answer.value);
    }
  }

  const result = await askTab({
    type: 'FILL_ALL_FIELDS',
    answers: Array.from(approvedAnswers.entries()),
  });

  if (result?.ok) {
    pageState.textContent = `✅ ${result.filled || approvedAnswers.size} answers inserted into form fields!`;
    insertAllButton.textContent = '✅ All Answers Inserted';
    questions.querySelectorAll('.insert').forEach((btn) => {
      btn.textContent = 'Inserted';
      btn.disabled = true;
    });
  }
});

// Auto-scan on sidepanel load
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(scan, 200);
});
